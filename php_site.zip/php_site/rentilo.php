<!DOCTYPE html>

<html>

  <head>

    <meta charset="UTF-8" />
    <link rel="stylesheet" href="rentilo.css">

    <title>RENTILO</title>

  </head>

  <body class="w3-container w3-gray">
    <h2>Nos produits aux prix imbattables chez RENTILO </h2>


    <table class="w3-table-all">
      <tr class="w3-red">
        <th>Id</th>
        <th>Nom</th>
        <th>prix(roupies)</th>
      </tr>
<?php
      try {

        $base = new PDO('mysql:host=localhost; dbname=rentilo', 'rentilo', 'rentilo');

      }

      catch(exception $e) {

        die('Erreur '.$e->getMessage());

      }

      $base->exec("SET CHARACTER SET utf8");

      $retour = $base->query('SELECT * FROM ventilo');

      while ($data = $retour->fetch()){


        echo '<tr>';
        echo '<th>'.$data['id'].'</th>';
        echo '<th>'.$data['nom'].'</th>';
        echo '<th>'.$data['prix'].'</th>';
        echo '</tr>';
        //echo $data['id'].' '.$data['nom'].' '.$data['prix'].'<br>';

      }

      $base = null;

    ?>

    </table>
    <BR><BR>
    Pour l admin---> <A HREF="rentilo_admin.php">section admin</A><BR><BR>
  </body>

</html>
