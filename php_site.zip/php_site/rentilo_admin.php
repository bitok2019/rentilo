
<!DOCTYPE html>

<html>

  <head>

    <meta charset="UTF-8" />
    <link rel="stylesheet" href="rentilo.css">
    <title>admin rentilo</title>

  </head>

  <body class="w3-container w3-gray">
    <h2>PAGE MODIFICATION ADMIN RENTILO </h2>


    <table class="w3-table-all">
      <tr class="w3-red">
        <th>Id</th>
        <th>Nom</th>
        <th>prix(roupies)</th>
      </tr>
<?php
      try {

        $base = new PDO('mysql:host=localhost; dbname=rentilo', 'rentilo', 'rentilo');

      }

      catch(exception $e) {

        die('Erreur '.$e->getMessage());

      }

      $base->exec("SET CHARACTER SET utf8");

      $retour = $base->query('SELECT * FROM ventilo');

      while ($data = $retour->fetch()){


        echo '<tr>';
        echo '<th>'.$data['id'].'</th>';
        echo '<th>'.$data['nom'].'</th>';
        echo '<th>'.$data['prix'].'</th>';
        //echo'Aller au formulaire produit --->';
        //echo '<th><A HREF="modifier_prt.php">';
        //echo 'Modifier</A></th>';
        //echo '</tr>';
        //echo ' <th><A HREF="suppr_prt.php">';
        //echo 'Suppr</A></th>';
        //echo '</tr>';
        //echo $data['id'].' '.$data['nom'].' '.$data['prix'].'<br>';

      }

      $base = null;

    ?>

    </tr>
    </table>
    <BR><BR>
    Pour ajouter un produit ---> <A HREF="formulaire_prt.php">FORMULAIRE AJOUT PRODUIT</A><BR><BR>


        <form method="post" action="suppr_prt.php" >
      entree l'id :<input type="number" name="id">
      <input type="submit" name="submit" value="Supprimer">
      <BR><BR>
      </form>
    <div class="w3-container">
      <form method="post" action="mod_prt.php" >
      entree l'id :<input type="number" name="id">
      <BR><BR>
      Nom du Produit :<input type="text" name="nom_prt">
      <BR><BR>
      Prix du produit : <input type="text" name="prix">


      <input type="submit" class="w3-button w3-black name="submit" value="Modifier">
    </form>
  </div>

  </body>

</html>
