
<!DOCTYPE html>

<html>

  <head>

    <meta charset="UTF-8" />
    <meta http-equiv="refresh" content="5;URL=rentilo.php">

  <title>modification du produit</title>

 </head>
 <body>

 <?php

 echo $_SESSION['id'];
 if (isset($_POST['nom_prt'])) {
   $nom = $_POST['nom_prt'];
 } else {
   $nom = '?';
 }
 if (isset($_POST['prix'])) {
   $prix = $_POST['prix'];
 } else {
   $prix = '?';
 }
 if (isset($_POST['id'])) {
   $id = $_POST['id'];
 } else {
   $id = '?';
 }

 echo "DITES KAMPY<BR><BR>\n";
 $servername = "localhost";
 $username = "rentilo";
 $password = "rentilo";
 $dbname = "rentilo";

 try {
     $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
     // set the PDO error mode to exception
     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     if ($nom != '?') {
     //$sql = "DELETE FROM ventilo WHERE id='$id'";
     $sql = "UPDATE ventilo SET nom='$nom' WHERE id='$id'";
    }
    if ($prix != '?') {
    //$sql = "DELETE FROM ventilo WHERE id='$id'";
    $sql = "UPDATE ventilo SET prix='$prix' WHERE id='$id'";
   }
   // Prepare statement
   $stmt = $conn->prepare($sql);

   // execute the query
   $stmt->execute();

   // echo a message to say the UPDATE succeeded
   echo $stmt->rowCount() . " records UPDATED successfully";
     // use exec() because no results are returned


     }
 catch(PDOException $e)
     {
     echo $sql . "<br>" . $e->getMessage();
     }

 $conn = null;
 ?>
 Aller a la liste des produits ---> <A HREF="rentilo.php">rentilo</A>

 </body>
</html>
