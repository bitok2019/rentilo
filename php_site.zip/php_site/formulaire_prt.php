<HTML>
<HEAD>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <TITLE>Nouveau Produit</TITLE>

 </HEAD>
 <BODY>
<DIV>
  <DIV>
    <UL>

      <LI> aller au formulaire client ---> <A HREF="formulaire_clt.php">FORMULAIRE CLIENT</A>


    </UL>

  </DIV>
 </DIV>
 <DIV>

 <H1>Nouveau Produit</H1>
 <BR>

 <CENTER>
 <FORM ACTION="verif_prt.php" METHOD="POST">
 NOM DU PRODUIT: <INPUT TYPE="text" NAME="nom_prt">
 <BR><BR>
 PRIX : <INPUT TYPE="text" NAME="prix">
 <BR><BR>

 <INPUT TYPE="submit" VALUE="Enregistrer">
 </FORM>
 </CENTER>

 <BR><BR><BR>

 </DIV>
 </BODY>
 </HTML>
