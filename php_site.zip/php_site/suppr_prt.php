
<!DOCTYPE html>

<html>

  <head>

    <meta charset="UTF-8" />
    <meta http-equiv="refresh" content="5;URL=rentilo.php">

  <title>Suppression du produit</title>

 </head>
 <body>

 <?php
 //echo '<p>Suppression du produit</p>';
 //$_SESSION['id']=15
 echo $_SESSION['id'];
 if (isset($_POST['nom_prt'])) {
   $nom = $_POST['nom_prt'];
 } else {
   $nom = '?';
 }
 if (isset($_POST['prix'])) {
   $prix = $_POST['prix'];
 } else {
   $prix = '?';
 }
 if (isset($_POST['id'])) {
   $id = $_POST['id'];
 } else {
   $id = '?';
 }
 echo "Voici le recapitulatif votre suppresion!\n";
 //echo $id;
 //echo "<BR><BR><BR>\n";

 //echo "Vous avez supprimé les valeurs suivantes :<BR>\n";
 //echo "<UL>\n";
 //echo "<LI> nom :    <EM>$nom</EM>\n";
 //echo "<LI> le prix du ventilo   :<EM>$prix</EM>.\n";
 //echo "</UL>\n";

 //echo "<BR>\n";


 echo "DITES KAMPY<BR><BR>\n";
 $servername = "localhost";
 $username = "rentilo";
 $password = "rentilo";
 $dbname = "rentilo";

 try {
     $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
     // set the PDO error mode to exception
     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

     $sql = "DELETE FROM ventilo WHERE id='$id'";
     // use exec() because no results are returned
    $conn->exec($sql);
    echo "Record deleted successfully";

     }
 catch(PDOException $e)
     {
     echo $sql . "<br>" . $e->getMessage();
     }

 $conn = null;
 ?>
Aller a la liste des produits ---> <A HREF="rentilo.php">rentilo</A>
 </body>
</html>
